import { Team } from "../utils/teams";
import { TeamCard } from "./TeamCard";

interface MatchDisplayProps {
  homeTeam: Team | null;
  awayTeam: Team | null;
}

export function MatchDisplay({ homeTeam, awayTeam }: MatchDisplayProps) {
  if (!homeTeam || !awayTeam) {
    return (
      <div className="text-center text-gray-500 text-xl py-12">
        Karşılaşma oluşturmak için butona tıklayın
      </div>
    );
  }

  return (
    <div className="flex flex-col md:flex-row items-center justify-center gap-4 md:gap-8 w-full max-w-4xl mx-auto">
      <div className="flex-1 w-full">
        <TeamCard team={homeTeam} />
      </div>
      
      <div className="flex-shrink-0">
        <div className="bg-red-600 text-white font-black text-3xl md:text-4xl px-6 py-3 rounded-xl shadow-lg">
          VS
        </div>
      </div>
      
      <div className="flex-1 w-full">
        <TeamCard team={awayTeam} />
      </div>
    </div>
  );
}