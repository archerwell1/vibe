import { Team } from "../utils/teams";
import { MapPin, Trophy } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../components/ui/card";

interface TeamCardProps {
  team: Team;
}

export function TeamCard({ team }: TeamCardProps) {
  return (
    <Card className="bg-gray-800 border-gray-700 shadow-xl hover:shadow-2xl transition-shadow duration-300">
      <CardHeader className="pb-3">
        <CardTitle className="text-xl md:text-2xl font-bold text-center text-white leading-tight">
          {team.name}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        <CardDescription className="flex items-center justify-center gap-2 text-gray-400 text-sm">
          <MapPin className="w-4 h-4" />
          {team.country}
        </CardDescription>
        <div className="flex items-center justify-center gap-2 text-amber-500 text-sm font-semibold">
          <Trophy className="w-4 h-4" />
          {team.league}
        </div>
      </CardContent>
    </Card>
  );
}