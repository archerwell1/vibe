import { useState } from "react";
import { Button } from "../components/ui/button";
import { MatchDisplay } from "../components/MatchDisplay";
import { getRandomTeams, Team } from "../utils/teams";
import { Trophy } from "lucide-react";

export default function App() {
  const [homeTeam, setHomeTeam] = useState<Team | null>(null);
  const [awayTeam, setAwayTeam] = useState<Team | null>(null);
  const [isAnimating, setIsAnimating] = useState(false);

  const generateMatch = () => {
    setIsAnimating(true);
    
    let shuffleCount = 0;
    const maxShuffles = 10;
    const shuffleInterval = setInterval(() => {
      const [team1, team2] = getRandomTeams();
      setHomeTeam(team1);
      setAwayTeam(team2);
      shuffleCount++;
      
      if (shuffleCount >= maxShuffles) {
        clearInterval(shuffleInterval);
        setIsAnimating(false);
      }
    }, 80);
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 flex flex-col items-center justify-center p-4 md:p-8">
      <div className="text-center mb-6 md:mb-10">
        <div className="flex items-center justify-center gap-3 mb-3">
          <Trophy className="w-9 h-9 md:w-11 md:h-11 text-yellow-500" />
          <h1 className="text-3xl md:text-4xl font-bold text-white">
            Rastgele Karşılaşma
          </h1>
        </div>
        <p className="text-gray-400 text-base md:text-lg">
          Avrupa'nın 6 büyük liginden takımlar
        </p>
      </div>

      <div className="w-full mb-6 md:mb-10">
        <MatchDisplay homeTeam={homeTeam} awayTeam={awayTeam} />
      </div>

      <Button
        onClick={generateMatch}
        disabled={isAnimating}
        className="bg-green-600 hover:bg-green-700 text-white text-base md:text-lg px-7 py-5 md:px-10 md:py-6 rounded-2xl font-bold shadow-lg hover:shadow-xl transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {isAnimating ? "Karşılaşma Oluşturuluyor..." : "Yeni Karşılaşma Oluştur"}
      </Button>

      <footer className="mt-10 md:mt-14 text-center text-gray-500 text-xs md:text-sm">
        <p>Premier League, La Liga, Bundesliga, Serie A, Ligue 1, Primeira Liga</p>
        <p className="mt-1">Toplam 114 takım arasından rastgele seçim</p>
      </footer>
    </div>
  );
}